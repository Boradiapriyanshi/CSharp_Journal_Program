﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace rop
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();

            int a, b;

            Console.WriteLine("Enter Value of A & B :");
            a = Convert.ToInt32(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());

            if (a == b)
            {
                Console.WriteLine("a = b");
            }
            if (a < b)
            {
                Console.WriteLine("a < b");
            }
            if (a > b)
            {
                Console.WriteLine("a > b");
            }
            if (a != b)
            {
                Console.WriteLine("a != b");
            }
            if (a <= b)
            {
                Console.WriteLine("a <= b");
            }
            if (a >= b)
            {
                Console.WriteLine("a >= b");
            }
            Console.Read();
            
        }
    }
}
