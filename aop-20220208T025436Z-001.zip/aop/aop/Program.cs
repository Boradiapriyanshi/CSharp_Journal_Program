﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace aop
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c;
            Console.WriteLine("input value of A & B :");
            a = Convert.ToInt32(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());

            c = a + b;
            Console.WriteLine("ADD =" + c);

            c = a - b;
            Console.WriteLine("Sub =" + c);

            c = a * b;
            Console.WriteLine("MUl =" + c);

            c = a / b;
            Console.WriteLine("Div =" + c);

            c = a % b;
            Console.WriteLine("MODULOS =" + c);
            Console.Read();
        }
    }
}
